package modelo.cuentas;

import modelo.abstractas.Cuenta;
import modelo.excepciones.CuentaBloqueadaException;
import modelo.excepciones.DatoInvalidoException;
import modelo.excepciones.SaldoInsuficienteException;
import modelo.interfaces.Consultable;
import modelo.interfaces.Transaccionable;

public class CuentaCorriente extends Cuenta implements Consultable, Transaccionable {
    private double montoSobregiro;
    private double comisionMantenimiento;

    public CuentaCorriente(String numeroCuenta, double saldoInicial, double montoSobregiro, double comisionMantenimiento) {
        super(numeroCuenta, saldoInicial);
        setMontoSobregiro(montoSobregiro);
        setComisionMantenimiento(comisionMantenimiento);
    }

    // Métodos abstractos de Cuenta
    @Override
    public double calcularInteres() {
        // No genera interés; retorna la comisión mensual como cargo
        return -comisionMantenimiento;
    }

    @Override
    public double getLimiteRetiro() {
        return getSaldo() + montoSobregiro;
    }

    @Override
    public String getTipoCuenta() {
        return "CORRIENTE";
    }

    // Implementación de Transaccionable
    @Override
    public void depositar(double monto) throws CuentaBloqueadaException {
        verificarBloqueada();
        if (monto <= 0) throw new DatoInvalidoException("monto", monto);
        incrementarSaldo(monto);
    }

    @Override
    public void retirar(double monto) throws SaldoInsuficienteException, CuentaBloqueadaException {
        verificarBloqueada();
        if (monto <= 0) throw new DatoInvalidoException("monto", monto);
        double disponible = getSaldo() + montoSobregiro;
        if (monto > disponible) {
            throw new SaldoInsuficienteException(getSaldo(), monto);
        }
        decrementarSaldo(monto);
    }

    @Override
    public double calcularComision(double monto) {
        return comisionMantenimiento;
    }

    @Override
    public double consultarSaldo() {
        return getSaldo();
    }

    // Implementación de Consultable
    @Override
    public String obtenerResumen() {
        return "Cuenta Corriente #" + getNumeroCuenta() +
                " | Saldo: $" + String.format("%.2f", getSaldo()) +
                " | Sobregiro permitido: $" + String.format("%.2f", montoSobregiro) +
                " | Comisión mensual: $" + String.format("%.2f", comisionMantenimiento);
    }

    @Override
    public boolean estaActivo() {
        return !isBloqueada();
    }

    @Override
    public String obtenerTipo() {
        return "CuentaCorriente";
    }

    // Getters y setters
    public double getMontoSobregiro() { return montoSobregiro; }
    public double getComisionMantenimiento() { return comisionMantenimiento; }

    public void setMontoSobregiro(double montoSobregiro) {
        if (montoSobregiro < 0) throw new DatoInvalidoException("montoSobregiro", montoSobregiro);
        this.montoSobregiro = montoSobregiro;
    }

    public void setComisionMantenimiento(double comisionMantenimiento) {
        if (comisionMantenimiento < 0) throw new DatoInvalidoException("comisionMantenimiento", comisionMantenimiento);
        this.comisionMantenimiento = comisionMantenimiento;
    }
}
