package modelo.cuentas;

import modelo.abstractas.Cuenta;
import modelo.excepciones.CuentaBloqueadaException;
import modelo.excepciones.DatoInvalidoException;
import modelo.excepciones.SaldoInsuficienteException;
import modelo.interfaces.Consultable;
import modelo.interfaces.Transaccionable;

public class CuentaCredito extends Cuenta implements Consultable, Transaccionable {
    private double limiteCredito;
    private double tasaInteres;
    private double deudaActual;

    public CuentaCredito(String numeroCuenta, double limiteCredito, double tasaInteres) {
        super(numeroCuenta, 0);
        setLimiteCredito(limiteCredito);
        setTasaInteres(tasaInteres);
        this.deudaActual = 0;
    }

    // Métodos abstractos de Cuenta
    @Override
    public double calcularInteres() {
        return deudaActual * tasaInteres / 12;
    }

    @Override
    public double getLimiteRetiro() {
        return limiteCredito - deudaActual;
    }

    @Override
    public String getTipoCuenta() {
        return "CREDITO";
    }

    // Implementación de Transaccionable
    @Override
    public void depositar(double monto) throws CuentaBloqueadaException {
        verificarBloqueada();
        if (monto <= 0) throw new DatoInvalidoException("monto", monto);
        // Pago de deuda
        deudaActual = Math.max(0, deudaActual - monto);
        incrementarSaldo(monto);
    }

    @Override
    public void retirar(double monto) throws SaldoInsuficienteException, CuentaBloqueadaException {
        verificarBloqueada();
        if (monto <= 0) throw new DatoInvalidoException("monto", monto);
        double disponible = limiteCredito - deudaActual;
        if (monto > disponible) {
            throw new SaldoInsuficienteException(disponible, monto);
        }
        deudaActual += monto;
        decrementarSaldo(monto < getSaldo() ? monto : 0);
    }

    @Override
    public double calcularComision(double monto) {
        return monto * 0.02; // 2% de comisión por transacción
    }

    @Override
    public double consultarSaldo() {
        return limiteCredito - deudaActual; // Saldo disponible en crédito
    }

    // Implementación de Consultable
    @Override
    public String obtenerResumen() {
        return "Cuenta Crédito #" + getNumeroCuenta() +
                " | Límite: $" + String.format("%.2f", limiteCredito) +
                " | Deuda actual: $" + String.format("%.2f", deudaActual) +
                " | Disponible: $" + String.format("%.2f", consultarSaldo()) +
                " | Tasa interés: " + (tasaInteres * 100) + "%";
    }

    @Override
    public boolean estaActivo() {
        return !isBloqueada();
    }

    @Override
    public String obtenerTipo() {
        return "CuentaCredito";
    }

    // Getters y setters
    public double getLimiteCredito() { return limiteCredito; }
    public double getTasaInteres() { return tasaInteres; }
    public double getDeudaActual() { return deudaActual; }

    public void setLimiteCredito(double limiteCredito) {
        if (limiteCredito <= 0) throw new DatoInvalidoException("limiteCredito", limiteCredito);
        this.limiteCredito = limiteCredito;
    }

    public void setTasaInteres(double tasaInteres) {
        if (tasaInteres < 0) throw new DatoInvalidoException("tasaInteres", tasaInteres);
        this.tasaInteres = tasaInteres;
    }
}
