package modelo.cuentas;

import modelo.abstractas.Cuenta;
import modelo.excepciones.CuentaBloqueadaException;
import modelo.excepciones.DatoInvalidoException;
import modelo.excepciones.SaldoInsuficienteException;
import modelo.interfaces.Consultable;
import modelo.interfaces.Transaccionable;

public class CuentaAhorros extends Cuenta implements Consultable, Transaccionable {
    private double tasaInteres;
    private int retirosMesActual;
    private int maxRetirosMes;

    public CuentaAhorros(String numeroCuenta, double saldoInicial, double tasaInteres, int maxRetirosMes) {
        super(numeroCuenta, saldoInicial);
        setTasaInteres(tasaInteres);
        setMaxRetirosMes(maxRetirosMes);
        this.retirosMesActual = 0;
    }

    // Métodos abstractos de Cuenta
    @Override
    public double calcularInteres() {
        return getSaldo() * tasaInteres / 12;
    }

    @Override
    public double getLimiteRetiro() {
        return getSaldo();
    }

    @Override
    public String getTipoCuenta() {
        return "AHORROS";
    }

    // Implementación de Transaccionable
    @Override
    public void depositar(double monto) throws CuentaBloqueadaException {
        verificarBloqueada();
        if (monto <= 0) throw new DatoInvalidoException("monto", monto);
        incrementarSaldo(monto);
    }

    @Override
    public void retirar(double monto) throws SaldoInsuficienteException, CuentaBloqueadaException {
        verificarBloqueada();
        if (monto <= 0) throw new DatoInvalidoException("monto", monto);
        if (monto > getSaldo()) {
            throw new SaldoInsuficienteException(getSaldo(), monto);
        }
        decrementarSaldo(monto);
        retirosMesActual++;
    }

    @Override
    public double calcularComision(double monto) {
        // Si supera el máximo de retiros, cobra comisión del 1%
        if (retirosMesActual >= maxRetirosMes) {
            return monto * 0.01;
        }
        return 0.0;
    }

    @Override
    public double consultarSaldo() {
        return getSaldo();
    }

    // Implementación de Consultable
    @Override
    public String obtenerResumen() {
        return "Cuenta Ahorros #" + getNumeroCuenta() +
                " | Saldo: $" + String.format("%.2f", getSaldo()) +
                " | Tasa: " + (tasaInteres * 100) + "%" +
                " | Retiros mes: " + retirosMesActual + "/" + maxRetirosMes;
    }

    @Override
    public boolean estaActivo() {
        return !isBloqueada();
    }

    @Override
    public String obtenerTipo() {
        return "CuentaAhorros";
    }

    // Getters y setters
    public double getTasaInteres() { return tasaInteres; }
    public int getRetirosMesActual() { return retirosMesActual; }
    public int getMaxRetirosMes() { return maxRetirosMes; }

    public void setTasaInteres(double tasaInteres) {
        if (tasaInteres < 0) throw new DatoInvalidoException("tasaInteres", tasaInteres);
        this.tasaInteres = tasaInteres;
    }

    public void setMaxRetirosMes(int maxRetirosMes) {
        if (maxRetirosMes <= 0) throw new DatoInvalidoException("maxRetirosMes", maxRetirosMes);
        this.maxRetirosMes = maxRetirosMes;
    }
}
