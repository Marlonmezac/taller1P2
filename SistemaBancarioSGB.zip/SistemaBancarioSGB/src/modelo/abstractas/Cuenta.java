package modelo.abstractas;

import modelo.banco.Transaccion;
import modelo.excepciones.CapacidadExcedidaException;
import modelo.excepciones.CuentaBloqueadaException;
import modelo.excepciones.DatoInvalidoException;
import modelo.interfaces.Auditable;

import java.time.LocalDateTime;

public abstract class Cuenta implements Auditable {
    private String numeroCuenta;
    private double saldo;
    private boolean bloqueada;
    private LocalDateTime fechaCreacion;
    private LocalDateTime ultimaModificacion;
    private String usuarioModificacion;

    private static final int MAX_HISTORIAL = 20;
    private Transaccion[] historial;
    private int contadorHistorial;

    public Cuenta(String numeroCuenta, double saldoInicial) {
        setNumeroCuenta(numeroCuenta);
        setSaldo(saldoInicial);
        this.bloqueada = false;
        this.fechaCreacion = LocalDateTime.now();
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = "SISTEMA";
        this.historial = new Transaccion[MAX_HISTORIAL];
        this.contadorHistorial = 0;
    }

    // Métodos abstractos
    public abstract double calcularInteres();
    public abstract double getLimiteRetiro();
    public abstract String getTipoCuenta();

    // Métodos concretos
    public void verificarBloqueada() throws CuentaBloqueadaException {
        if (bloqueada) {
            throw new CuentaBloqueadaException(numeroCuenta);
        }
    }

    public void agregarAlHistorial(Transaccion t) throws CapacidadExcedidaException {
        if (contadorHistorial >= MAX_HISTORIAL) {
            throw new CapacidadExcedidaException("historial de transacciones de cuenta " + numeroCuenta, MAX_HISTORIAL);
        }
        historial[contadorHistorial] = t;
        contadorHistorial++;
    }

    public Transaccion[] getHistorial() {
        Transaccion[] copia = new Transaccion[contadorHistorial];
        System.arraycopy(historial, 0, copia, 0, contadorHistorial);
        return copia;
    }

    // Implementación de Auditable
    @Override
    public LocalDateTime obtenerFechaCreacion() {
        return fechaCreacion;
    }

    @Override
    public LocalDateTime obtenerUltimaModificacion() {
        return ultimaModificacion;
    }

    @Override
    public String obtenerUsuarioModificacion() {
        return usuarioModificacion;
    }

    @Override
    public void registrarModificacion(String usuario) {
        if (usuario == null || usuario.isBlank()) {
            throw new DatoInvalidoException("usuario", usuario);
        }
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = usuario;
    }

    // Getters
    public String getNumeroCuenta() { return numeroCuenta; }
    public double getSaldo() { return saldo; }
    public boolean isBloqueada() { return bloqueada; }
    public int getContadorHistorial() { return contadorHistorial; }

    // Setters con validación
    public void setNumeroCuenta(String numeroCuenta) {
        if (numeroCuenta == null || numeroCuenta.isBlank()) {
            throw new DatoInvalidoException("numeroCuenta", numeroCuenta);
        }
        this.numeroCuenta = numeroCuenta;
    }

    public void setSaldo(double saldo) {
        if (saldo < 0) {
            throw new DatoInvalidoException("saldo", saldo);
        }
        this.saldo = saldo;
    }

    public void setBloqueada(boolean bloqueada) {
        this.bloqueada = bloqueada;
    }

    protected void incrementarSaldo(double monto) {
        this.saldo += monto;
    }

    protected void decrementarSaldo(double monto) {
        this.saldo -= monto;
    }

    @Override
    public String toString() {
        return "[" + getTipoCuenta() + "] Cuenta: " + numeroCuenta + " | Saldo: $" + String.format("%.2f", saldo) + " | Bloqueada: " + bloqueada;
    }
}
