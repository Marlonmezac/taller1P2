package modelo.abstractas;

import modelo.excepciones.CapacidadExcedidaException;
import modelo.excepciones.DatoInvalidoException;

import java.time.LocalDate;

public abstract class Cliente extends Persona {
    private static final int MAX_CUENTAS = 5;
    private Cuenta[] cuentas;
    private int contadorCuentas;

    public Cliente(String id, String nombre, String apellido, LocalDate fechaNacimiento, String email) {
        super(id, nombre, apellido, fechaNacimiento, email);
        this.cuentas = new Cuenta[MAX_CUENTAS];
        this.contadorCuentas = 0;
    }

    public void agregarCuenta(Cuenta cuenta) throws CapacidadExcedidaException {
        if (cuenta == null) {
            throw new DatoInvalidoException("cuenta", null);
        }
        if (contadorCuentas >= MAX_CUENTAS) {
            throw new CapacidadExcedidaException("cuentas por cliente", MAX_CUENTAS);
        }
        cuentas[contadorCuentas] = cuenta;
        contadorCuentas++;
    }

    public Cuenta[] getCuentas() {
        Cuenta[] copia = new Cuenta[contadorCuentas];
        System.arraycopy(cuentas, 0, copia, 0, contadorCuentas);
        return copia;
    }

    public int getContadorCuentas() { return contadorCuentas; }
}
