package modelo.empleados;

import modelo.abstractas.Empleado;
import modelo.excepciones.CapacidadExcedidaException;
import modelo.excepciones.DatoInvalidoException;
import modelo.excepciones.PermisoInsuficienteException;
import modelo.interfaces.Auditable;
import modelo.interfaces.Consultable;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class GerenteSucursal extends Empleado implements Consultable, Auditable {
    private String sucursal;
    private double presupuestoAnual;
    private static final int MAX_EMPLEADOS = 30;
    private Empleado[] empleadosACargo;
    private int contadorEmpleados;
    private static final double BONO_GERENCIA = 5000000.0;
    private static final double BONO_ANTIGUEDAD_POR_AÑO = 200000.0;
    private LocalDateTime fechaCreacion;
    private LocalDateTime ultimaModificacion;
    private String usuarioModificacion;

    public GerenteSucursal(String id, String nombre, String apellido, LocalDate fechaNacimiento,
                            String email, String legajo, LocalDate fechaContratacion, double salarioBase,
                            String sucursal, double presupuestoAnual) {
        super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase);
        setSucursal(sucursal);
        setPresupuestoAnual(presupuestoAnual);
        this.empleadosACargo = new Empleado[MAX_EMPLEADOS];
        this.contadorEmpleados = 0;
        this.fechaCreacion = LocalDateTime.now();
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = "SISTEMA";
    }

    // Métodos abstractos de Empleado
    @Override
    public double calcularSalario() {
        return getSalarioBase() + calcularBono();
    }

    @Override
    public double calcularBono() {
        return BONO_GERENCIA + (calcularAntigüedad() * BONO_ANTIGUEDAD_POR_AÑO);
    }

    // Métodos abstractos de Persona
    @Override
    public int calcularEdad() {
        return calcularEdadBase();
    }

    @Override
    public String obtenerTipo() {
        return "GerenteSucursal";
    }

    @Override
    public String obtenerDocumentoIdentidad() {
        return "Legajo: " + getLegajo();
    }

    public void aprobarCredito(Empleado solicitante, double monto) {
        if (!(solicitante instanceof GerenteSucursal)) {
            throw new PermisoInsuficienteException("aprobar crédito — solo el Gerente de Sucursal puede realizar esta acción");
        }
        System.out.println("[CRÉDITO APROBADO] Monto: $" + String.format("%.2f", monto) + " aprobado por " + getNombreCompleto());
    }

    public void agregarEmpleadoACargo(Empleado empleado) throws CapacidadExcedidaException {
        if (empleado == null) throw new DatoInvalidoException("empleado", null);
        if (contadorEmpleados >= MAX_EMPLEADOS) {
            throw new CapacidadExcedidaException("empleados a cargo del gerente", MAX_EMPLEADOS);
        }
        empleadosACargo[contadorEmpleados] = empleado;
        contadorEmpleados++;
    }

    public Empleado[] getEmpleadosACargo() {
        Empleado[] copia = new Empleado[contadorEmpleados];
        System.arraycopy(empleadosACargo, 0, copia, 0, contadorEmpleados);
        return copia;
    }

    // Implementación de Consultable
    @Override
    public String obtenerResumen() {
        return "Gerente de Sucursal | " + getNombreCompleto() +
                " | Sucursal: " + sucursal +
                " | Antigüedad: " + calcularAntigüedad() + " años" +
                " | Empleados a cargo: " + contadorEmpleados +
                " | Salario: $" + String.format("%.2f", calcularSalario());
    }

    @Override
    public boolean estaActivo() {
        return isActivo();
    }

    // Implementación de Auditable
    @Override
    public LocalDateTime obtenerFechaCreacion() { return fechaCreacion; }

    @Override
    public LocalDateTime obtenerUltimaModificacion() { return ultimaModificacion; }

    @Override
    public String obtenerUsuarioModificacion() { return usuarioModificacion; }

    @Override
    public void registrarModificacion(String usuario) {
        if (usuario == null || usuario.isBlank()) throw new DatoInvalidoException("usuario", usuario);
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = usuario;
    }

    // Getters y setters
    public String getSucursal() { return sucursal; }
    public double getPresupuestoAnual() { return presupuestoAnual; }

    public void setSucursal(String sucursal) {
        if (sucursal == null || sucursal.isBlank()) throw new DatoInvalidoException("sucursal", sucursal);
        this.sucursal = sucursal;
    }

    public void setPresupuestoAnual(double presupuestoAnual) {
        if (presupuestoAnual < 0) throw new DatoInvalidoException("presupuestoAnual", presupuestoAnual);
        this.presupuestoAnual = presupuestoAnual;
    }

    @Override
    public String toString() {
        return obtenerResumen();
    }
}
