package modelo.empleados;

import modelo.abstractas.Empleado;
import modelo.enums.Turno;
import modelo.excepciones.DatoInvalidoException;

import java.time.LocalDate;

public class Cajero extends Empleado {
    private Turno turno;
    private String sucursalAsignada;
    private int transaccionesDia;

    // Bono por cada transacción procesada
    private static final double BONO_POR_TRANSACCION = 500.0;

    public Cajero(String id, String nombre, String apellido, LocalDate fechaNacimiento,
                  String email, String legajo, LocalDate fechaContratacion, double salarioBase,
                  Turno turno, String sucursalAsignada) {
        super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase);
        setTurno(turno);
        setSucursalAsignada(sucursalAsignada);
        this.transaccionesDia = 0;
    }

    // Métodos abstractos de Empleado
    @Override
    public double calcularSalario() {
        return getSalarioBase() + calcularBono();
    }

    @Override
    public double calcularBono() {
        return transaccionesDia * BONO_POR_TRANSACCION;
    }

    // Métodos abstractos de Persona
    @Override
    public int calcularEdad() {
        return calcularEdadBase();
    }

    @Override
    public String obtenerTipo() {
        return "Cajero";
    }

    @Override
    public String obtenerDocumentoIdentidad() {
        return "Legajo: " + getLegajo();
    }

    public void registrarTransaccion() {
        this.transaccionesDia++;
    }

    // Getters y setters
    public Turno getTurno() { return turno; }
    public String getSucursalAsignada() { return sucursalAsignada; }
    public int getTransaccionesDia() { return transaccionesDia; }

    public void setTurno(Turno turno) {
        if (turno == null) throw new DatoInvalidoException("turno", null);
        this.turno = turno;
    }

    public void setSucursalAsignada(String sucursalAsignada) {
        if (sucursalAsignada == null || sucursalAsignada.isBlank()) throw new DatoInvalidoException("sucursalAsignada", sucursalAsignada);
        this.sucursalAsignada = sucursalAsignada;
    }

    public void setTransaccionesDia(int transaccionesDia) {
        if (transaccionesDia < 0) throw new DatoInvalidoException("transaccionesDia", transaccionesDia);
        this.transaccionesDia = transaccionesDia;
    }

    @Override
    public String toString() {
        return "Cajero | " + getNombreCompleto() +
                " | Turno: " + turno +
                " | Sucursal: " + sucursalAsignada +
                " | Transacciones hoy: " + transaccionesDia +
                " | Salario: $" + String.format("%.2f", calcularSalario());
    }
}
