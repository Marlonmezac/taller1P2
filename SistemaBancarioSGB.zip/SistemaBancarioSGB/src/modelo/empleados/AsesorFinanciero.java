package modelo.empleados;

import modelo.abstractas.Cliente;
import modelo.abstractas.Empleado;
import modelo.excepciones.CapacidadExcedidaException;
import modelo.excepciones.DatoInvalidoException;
import modelo.interfaces.Auditable;
import modelo.interfaces.Consultable;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class AsesorFinanciero extends Empleado implements Consultable, Auditable {
    private double comisionBase;
    private double metasMensuales;
    private double ventasMesActual;
    private static final int MAX_CLIENTES = 20;
    private Cliente[] clientesAsignados;
    private int contadorClientes;
    private LocalDateTime fechaCreacion;
    private LocalDateTime ultimaModificacion;
    private String usuarioModificacion;

    public AsesorFinanciero(String id, String nombre, String apellido, LocalDate fechaNacimiento,
                             String email, String legajo, LocalDate fechaContratacion, double salarioBase,
                             double comisionBase, double metasMensuales) {
        super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase);
        setComisionBase(comisionBase);
        setMetasMensuales(metasMensuales);
        this.ventasMesActual = 0;
        this.clientesAsignados = new Cliente[MAX_CLIENTES];
        this.contadorClientes = 0;
        this.fechaCreacion = LocalDateTime.now();
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = "SISTEMA";
    }

    // Métodos abstractos de Empleado
    @Override
    public double calcularSalario() {
        return getSalarioBase() + calcularBono();
    }

    @Override
    public double calcularBono() {
        if (ventasMesActual >= metasMensuales) {
            return comisionBase * (ventasMesActual / metasMensuales);
        }
        return 0.0;
    }

    // Métodos abstractos de Persona
    @Override
    public int calcularEdad() {
        return calcularEdadBase();
    }

    @Override
    public String obtenerTipo() {
        return "AsesorFinanciero";
    }

    @Override
    public String obtenerDocumentoIdentidad() {
        return "Legajo: " + getLegajo();
    }

    public void asignarCliente(Cliente cliente) throws CapacidadExcedidaException {
        if (cliente == null) throw new DatoInvalidoException("cliente", null);
        if (contadorClientes >= MAX_CLIENTES) {
            throw new CapacidadExcedidaException("clientes por asesor", MAX_CLIENTES);
        }
        clientesAsignados[contadorClientes] = cliente;
        contadorClientes++;
    }

    public Cliente[] getClientesAsignados() {
        Cliente[] copia = new Cliente[contadorClientes];
        System.arraycopy(clientesAsignados, 0, copia, 0, contadorClientes);
        return copia;
    }

    // Implementación de Consultable
    @Override
    public String obtenerResumen() {
        return "Asesor Financiero | " + getNombreCompleto() +
                " | Legajo: " + getLegajo() +
                " | Clientes asignados: " + contadorClientes +
                " | Ventas mes: $" + String.format("%.2f", ventasMesActual) +
                " | Meta: $" + String.format("%.2f", metasMensuales) +
                " | Salario: $" + String.format("%.2f", calcularSalario());
    }

    @Override
    public boolean estaActivo() {
        return isActivo();
    }

    // Implementación de Auditable
    @Override
    public LocalDateTime obtenerFechaCreacion() { return fechaCreacion; }

    @Override
    public LocalDateTime obtenerUltimaModificacion() { return ultimaModificacion; }

    @Override
    public String obtenerUsuarioModificacion() { return usuarioModificacion; }

    @Override
    public void registrarModificacion(String usuario) {
        if (usuario == null || usuario.isBlank()) throw new DatoInvalidoException("usuario", usuario);
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = usuario;
    }

    // Getters y setters
    public double getComisionBase() { return comisionBase; }
    public double getMetasMensuales() { return metasMensuales; }
    public double getVentasMesActual() { return ventasMesActual; }

    public void setComisionBase(double comisionBase) {
        if (comisionBase < 0) throw new DatoInvalidoException("comisionBase", comisionBase);
        this.comisionBase = comisionBase;
    }

    public void setMetasMensuales(double metasMensuales) {
        if (metasMensuales <= 0) throw new DatoInvalidoException("metasMensuales", metasMensuales);
        this.metasMensuales = metasMensuales;
    }

    public void setVentasMesActual(double ventasMesActual) {
        if (ventasMesActual < 0) throw new DatoInvalidoException("ventasMesActual", ventasMesActual);
        this.ventasMesActual = ventasMesActual;
    }

    @Override
    public String toString() {
        return obtenerResumen();
    }
}
