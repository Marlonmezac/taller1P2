package modelo.personas;

import modelo.abstractas.Cliente;
import modelo.enums.TipoDocumento;
import modelo.excepciones.DatoInvalidoException;
import modelo.interfaces.Auditable;
import modelo.interfaces.Consultable;
import modelo.interfaces.Notificable;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class ClienteNatural extends Cliente implements Consultable, Notificable, Auditable {
    private TipoDocumento tipoDocumento;
    private String numeroDocumento;
    private boolean notificacionesActivas;
    private LocalDateTime fechaCreacion;
    private LocalDateTime ultimaModificacion;
    private String usuarioModificacion;

    public ClienteNatural(String id, String nombre, String apellido, LocalDate fechaNacimiento,
                          String email, TipoDocumento tipoDocumento, String numeroDocumento,
                          boolean notificacionesActivas) {
        super(id, nombre, apellido, fechaNacimiento, email);
        setTipoDocumento(tipoDocumento);
        setNumeroDocumento(numeroDocumento);
        this.notificacionesActivas = notificacionesActivas;
        this.fechaCreacion = LocalDateTime.now();
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = "SISTEMA";
    }

    // Métodos abstractos de Persona
    @Override
    public int calcularEdad() {
        return calcularEdadBase();
    }

    @Override
    public String obtenerTipo() {
        return "ClienteNatural";
    }

    @Override
    public String obtenerDocumentoIdentidad() {
        return tipoDocumento.name() + ": " + numeroDocumento;
    }

    // Implementación de Consultable
    @Override
    public String obtenerResumen() {
        return "Cliente Natural | " + getNombreCompleto() +
                " | " + obtenerDocumentoIdentidad() +
                " | Email: " + getEmail() +
                " | Edad: " + calcularEdad() + " años" +
                " | Cuentas: " + getContadorCuentas();
    }

    @Override
    public boolean estaActivo() {
        return true;
    }

    // Implementación de Notificable
    @Override
    public void notificar(String mensaje) {
        if (aceptaNotificaciones()) {
            System.out.println("[NOTIFICACIÓN → " + getNombreCompleto() + "] " + mensaje);
        } else {
            System.out.println("[NOTIFICACIÓN BLOQUEADA] " + getNombreCompleto() + " no acepta notificaciones.");
        }
    }

    @Override
    public String obtenerContacto() {
        return getEmail();
    }

    @Override
    public boolean aceptaNotificaciones() {
        return notificacionesActivas;
    }

    // Implementación de Auditable
    @Override
    public LocalDateTime obtenerFechaCreacion() { return fechaCreacion; }

    @Override
    public LocalDateTime obtenerUltimaModificacion() { return ultimaModificacion; }

    @Override
    public String obtenerUsuarioModificacion() { return usuarioModificacion; }

    @Override
    public void registrarModificacion(String usuario) {
        if (usuario == null || usuario.isBlank()) throw new DatoInvalidoException("usuario", usuario);
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = usuario;
    }

    // Getters y setters
    public TipoDocumento getTipoDocumento() { return tipoDocumento; }
    public String getNumeroDocumento() { return numeroDocumento; }

    public void setTipoDocumento(TipoDocumento tipoDocumento) {
        if (tipoDocumento == null) throw new DatoInvalidoException("tipoDocumento", null);
        this.tipoDocumento = tipoDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        if (numeroDocumento == null || numeroDocumento.isBlank()) throw new DatoInvalidoException("numeroDocumento", numeroDocumento);
        this.numeroDocumento = numeroDocumento;
    }

    public void setNotificacionesActivas(boolean notificacionesActivas) {
        this.notificacionesActivas = notificacionesActivas;
    }
}
