package modelo.personas;

import modelo.abstractas.Cliente;
import modelo.excepciones.DatoInvalidoException;
import modelo.interfaces.Auditable;
import modelo.interfaces.Consultable;
import modelo.interfaces.Notificable;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class ClienteEmpresarial extends Cliente implements Consultable, Notificable, Auditable {
    private String nit;
    private String razonSocial;
    private String representanteLegal;
    private boolean notificacionesActivas;
    private LocalDateTime fechaCreacion;
    private LocalDateTime ultimaModificacion;
    private String usuarioModificacion;

    public ClienteEmpresarial(String id, String nombre, String apellido, LocalDate fechaNacimiento,
                               String email, String nit, String razonSocial, String representanteLegal,
                               boolean notificacionesActivas) {
        super(id, nombre, apellido, fechaNacimiento, email);
        setNit(nit);
        setRazonSocial(razonSocial);
        setRepresentanteLegal(representanteLegal);
        this.notificacionesActivas = notificacionesActivas;
        this.fechaCreacion = LocalDateTime.now();
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = "SISTEMA";
    }

    // Métodos abstractos de Persona
    @Override
    public int calcularEdad() {
        return calcularEdadBase();
    }

    @Override
    public String obtenerTipo() {
        return "ClienteEmpresarial";
    }

    @Override
    public String obtenerDocumentoIdentidad() {
        return "NIT: " + nit;
    }

    // Implementación de Consultable
    @Override
    public String obtenerResumen() {
        return "Cliente Empresarial | " + razonSocial +
                " | NIT: " + nit +
                " | Representante: " + representanteLegal +
                " | Email: " + getEmail() +
                " | Cuentas: " + getContadorCuentas();
    }

    @Override
    public boolean estaActivo() {
        return true;
    }

    // Implementación de Notificable
    @Override
    public void notificar(String mensaje) {
        if (aceptaNotificaciones()) {
            System.out.println("[NOTIFICACIÓN EMPRESA → " + razonSocial + "] " + mensaje);
        } else {
            System.out.println("[NOTIFICACIÓN BLOQUEADA] " + razonSocial + " no acepta notificaciones.");
        }
    }

    @Override
    public String obtenerContacto() {
        return getEmail();
    }

    @Override
    public boolean aceptaNotificaciones() {
        return notificacionesActivas;
    }

    // Implementación de Auditable
    @Override
    public LocalDateTime obtenerFechaCreacion() { return fechaCreacion; }

    @Override
    public LocalDateTime obtenerUltimaModificacion() { return ultimaModificacion; }

    @Override
    public String obtenerUsuarioModificacion() { return usuarioModificacion; }

    @Override
    public void registrarModificacion(String usuario) {
        if (usuario == null || usuario.isBlank()) throw new DatoInvalidoException("usuario", usuario);
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = usuario;
    }

    // Getters y setters
    public String getNit() { return nit; }
    public String getRazonSocial() { return razonSocial; }
    public String getRepresentanteLegal() { return representanteLegal; }

    public void setNit(String nit) {
        if (nit == null || nit.isBlank()) throw new DatoInvalidoException("nit", nit);
        this.nit = nit;
    }

    public void setRazonSocial(String razonSocial) {
        if (razonSocial == null || razonSocial.isBlank()) throw new DatoInvalidoException("razonSocial", razonSocial);
        this.razonSocial = razonSocial;
    }

    public void setRepresentanteLegal(String representanteLegal) {
        if (representanteLegal == null || representanteLegal.isBlank()) throw new DatoInvalidoException("representanteLegal", representanteLegal);
        this.representanteLegal = representanteLegal;
    }

    public void setNotificacionesActivas(boolean notificacionesActivas) {
        this.notificacionesActivas = notificacionesActivas;
    }
}
