package modelo.banco;

import modelo.abstractas.Cuenta;
import modelo.enums.EstadoTransaccion;
import modelo.excepciones.DatoInvalidoException;
import modelo.excepciones.EstadoTransaccionInvalidoException;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Transaccion {
    private String id;
    private Cuenta cuentaOrigen;
    private Cuenta cuentaDestino; // puede ser null en depósitos/retiros
    private double monto;
    private EstadoTransaccion estado;
    private LocalDateTime fecha;
    private String descripcion;

    public Transaccion(String id, Cuenta cuentaOrigen, Cuenta cuentaDestino,
                       double monto, String descripcion) {
        setId(id);
        setCuentaOrigen(cuentaOrigen);
        this.cuentaDestino = cuentaDestino; // puede ser null
        setMonto(monto);
        setDescripcion(descripcion);
        this.estado = EstadoTransaccion.PENDIENTE;
        this.fecha = LocalDateTime.now();
    }

    public void cambiarEstado(EstadoTransaccion nuevo) {
        boolean transicionValida = switch (estado) {
            case PENDIENTE   -> nuevo == EstadoTransaccion.PROCESANDO || nuevo == EstadoTransaccion.RECHAZADA;
            case PROCESANDO  -> nuevo == EstadoTransaccion.COMPLETADA || nuevo == EstadoTransaccion.RECHAZADA;
            case COMPLETADA  -> nuevo == EstadoTransaccion.REVERTIDA;
            case RECHAZADA   -> false;
            case REVERTIDA   -> false;
        };

        if (!transicionValida) {
            throw new EstadoTransaccionInvalidoException(estado, nuevo);
        }
        this.estado = nuevo;
    }

    public String generarComprobante() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        StringBuilder sb = new StringBuilder();
        sb.append("========================================\n");
        sb.append("         COMPROBANTE DE TRANSACCIÓN     \n");
        sb.append("========================================\n");
        sb.append("ID:          ").append(id).append("\n");
        sb.append("Fecha:       ").append(fecha.format(fmt)).append("\n");
        sb.append("Estado:      ").append(estado).append("\n");
        sb.append("Monto:       $").append(String.format("%.2f", monto)).append("\n");
        sb.append("Cuenta Ori.: ").append(cuentaOrigen.getNumeroCuenta()).append("\n");
        if (cuentaDestino != null) {
            sb.append("Cuenta Dst.: ").append(cuentaDestino.getNumeroCuenta()).append("\n");
        }
        sb.append("Descripción: ").append(descripcion).append("\n");
        sb.append("========================================\n");
        return sb.toString();
    }

    // Getters
    public String getId() { return id; }
    public Cuenta getCuentaOrigen() { return cuentaOrigen; }
    public Cuenta getCuentaDestino() { return cuentaDestino; }
    public double getMonto() { return monto; }
    public EstadoTransaccion getEstado() { return estado; }
    public LocalDateTime getFecha() { return fecha; }
    public String getDescripcion() { return descripcion; }

    // Setters con validación
    public void setId(String id) {
        if (id == null || id.isBlank()) throw new DatoInvalidoException("id", id);
        this.id = id;
    }

    public void setCuentaOrigen(Cuenta cuentaOrigen) {
        if (cuentaOrigen == null) throw new DatoInvalidoException("cuentaOrigen", null);
        this.cuentaOrigen = cuentaOrigen;
    }

    public void setMonto(double monto) {
        if (monto <= 0) throw new DatoInvalidoException("monto", monto);
        this.monto = monto;
    }

    public void setDescripcion(String descripcion) {
        if (descripcion == null || descripcion.isBlank()) throw new DatoInvalidoException("descripcion", descripcion);
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "Transaccion{id='" + id + "', monto=" + monto + ", estado=" + estado + ", fecha=" + fecha + '}';
    }
}
