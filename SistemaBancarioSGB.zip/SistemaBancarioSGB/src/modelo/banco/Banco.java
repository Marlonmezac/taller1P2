package modelo.banco;

import modelo.abstractas.Cliente;
import modelo.abstractas.Cuenta;
import modelo.abstractas.Empleado;
import modelo.excepciones.CapacidadExcedidaException;
import modelo.excepciones.ClienteNoEncontradoException;
import modelo.excepciones.DatoInvalidoException;
import modelo.interfaces.Auditable;

import java.time.LocalDateTime;

public class Banco implements Auditable {
    private String nombre;
    private static final int MAX_EMPLEADOS = 50;
    private static final int MAX_CLIENTES = 200;
    private static final int MAX_CUENTAS = 500;

    private Empleado[] empleados;
    private int contadorEmpleados;
    private Cliente[] clientes;
    private int contadorClientes;
    private Cuenta[] cuentas;
    private int contadorCuentas;

    private LocalDateTime fechaCreacion;
    private LocalDateTime ultimaModificacion;
    private String usuarioModificacion;

    public Banco(String nombre) {
        setNombre(nombre);
        this.empleados = new Empleado[MAX_EMPLEADOS];
        this.clientes = new Cliente[MAX_CLIENTES];
        this.cuentas = new Cuenta[MAX_CUENTAS];
        this.contadorEmpleados = 0;
        this.contadorClientes = 0;
        this.contadorCuentas = 0;
        this.fechaCreacion = LocalDateTime.now();
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = "SISTEMA";
    }

    public void registrarCliente(Cliente cliente) throws CapacidadExcedidaException {
        if (cliente == null) throw new DatoInvalidoException("cliente", null);
        if (contadorClientes >= MAX_CLIENTES) {
            throw new CapacidadExcedidaException("clientes del banco", MAX_CLIENTES);
        }
        clientes[contadorClientes] = cliente;
        contadorClientes++;
        System.out.println("[BANCO] Cliente registrado: " + cliente.getNombreCompleto());
    }

    public void registrarEmpleado(Empleado empleado) throws CapacidadExcedidaException {
        if (empleado == null) throw new DatoInvalidoException("empleado", null);
        if (contadorEmpleados >= MAX_EMPLEADOS) {
            throw new CapacidadExcedidaException("empleados del banco", MAX_EMPLEADOS);
        }
        empleados[contadorEmpleados] = empleado;
        contadorEmpleados++;
        System.out.println("[BANCO] Empleado registrado: " + empleado.getNombreCompleto() + " (" + empleado.obtenerTipo() + ")");
    }

    public void abrirCuenta(String idCliente, Cuenta cuenta) throws ClienteNoEncontradoException, CapacidadExcedidaException {
        if (cuenta == null) throw new DatoInvalidoException("cuenta", null);
        if (contadorCuentas >= MAX_CUENTAS) {
            throw new CapacidadExcedidaException("cuentas del banco", MAX_CUENTAS);
        }
        Cliente cliente = buscarCliente(idCliente);
        cliente.agregarCuenta(cuenta);
        cuentas[contadorCuentas] = cuenta;
        contadorCuentas++;
        System.out.println("[BANCO] Cuenta " + cuenta.getNumeroCuenta() + " (" + cuenta.getTipoCuenta() + ") abierta para " + cliente.getNombreCompleto());
    }

    public Cliente buscarCliente(String id) throws ClienteNoEncontradoException {
        if (id == null || id.isBlank()) throw new DatoInvalidoException("id", id);
        for (int i = 0; i < contadorClientes; i++) {
            if (clientes[i].getId().equals(id)) {
                return clientes[i];
            }
        }
        throw new ClienteNoEncontradoException(id);
    }

    public double calcularNominaTotal() {
        double total = 0;
        for (int i = 0; i < contadorEmpleados; i++) {
            total += empleados[i].calcularSalario(); // polimorfismo
        }
        return total;
    }

    public void calcularInteresesMensuales() {
        System.out.println("\n[BANCO] Cálculo de intereses/cargos mensuales:");
        for (int i = 0; i < contadorCuentas; i++) {
            double interes = cuentas[i].calcularInteres(); // polimorfismo
            String etiqueta = interes >= 0 ? "Interés" : "Cargo";
            System.out.printf("  Cuenta %s (%s): %s mensual = $%.2f%n",
                    cuentas[i].getNumeroCuenta(),
                    cuentas[i].getTipoCuenta(),
                    etiqueta,
                    Math.abs(interes));
        }
    }

    // Implementación de Auditable
    @Override
    public LocalDateTime obtenerFechaCreacion() { return fechaCreacion; }

    @Override
    public LocalDateTime obtenerUltimaModificacion() { return ultimaModificacion; }

    @Override
    public String obtenerUsuarioModificacion() { return usuarioModificacion; }

    @Override
    public void registrarModificacion(String usuario) {
        if (usuario == null || usuario.isBlank()) throw new DatoInvalidoException("usuario", usuario);
        this.ultimaModificacion = LocalDateTime.now();
        this.usuarioModificacion = usuario;
    }

    // Getters
    public String getNombre() { return nombre; }
    public int getContadorClientes() { return contadorClientes; }
    public int getContadorEmpleados() { return contadorEmpleados; }
    public int getContadorCuentas() { return contadorCuentas; }

    public Empleado[] getEmpleados() {
        Empleado[] copia = new Empleado[contadorEmpleados];
        System.arraycopy(empleados, 0, copia, 0, contadorEmpleados);
        return copia;
    }

    public Cliente[] getClientes() {
        Cliente[] copia = new Cliente[contadorClientes];
        System.arraycopy(clientes, 0, copia, 0, contadorClientes);
        return copia;
    }

    public Cuenta[] getCuentas() {
        Cuenta[] copia = new Cuenta[contadorCuentas];
        System.arraycopy(cuentas, 0, copia, 0, contadorCuentas);
        return copia;
    }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.isBlank()) throw new DatoInvalidoException("nombre", nombre);
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Banco: " + nombre + " | Clientes: " + contadorClientes + " | Empleados: " + contadorEmpleados + " | Cuentas: " + contadorCuentas;
    }
}
