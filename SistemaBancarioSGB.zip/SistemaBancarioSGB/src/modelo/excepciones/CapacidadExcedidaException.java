package modelo.excepciones;

public class CapacidadExcedidaException extends SistemaBancarioException {
    private final int capacidadMaxima;

    public CapacidadExcedidaException(String entidad, int capacidadMaxima) {
        super("Se ha alcanzado la capacidad máxima de " + capacidadMaxima + " para: " + entidad, "ERR-CAP-001");
        this.capacidadMaxima = capacidadMaxima;
    }

    public int getCapacidadMaxima() {
        return capacidadMaxima;
    }

    @Override
    public String toString() {
        return "CapacidadExcedidaException{" +
                "capacidadMaxima=" + capacidadMaxima +
                ", codigoError='" + getCodigoError() + '\'' +
                '}';
    }
}
