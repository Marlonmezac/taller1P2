package modelo.excepciones;

public class ClienteNoEncontradoException extends SistemaBancarioException {
    private final String idCliente;

    public ClienteNoEncontradoException(String idCliente) {
        super("No se encontró ningún cliente con el ID: " + idCliente, "ERR-CLIENTE-001");
        this.idCliente = idCliente;
    }

    public String getIdCliente() {
        return idCliente;
    }

    @Override
    public String toString() {
        return "ClienteNoEncontradoException{" +
                "idCliente='" + idCliente + '\'' +
                ", codigoError='" + getCodigoError() + '\'' +
                '}';
    }
}
