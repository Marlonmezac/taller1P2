package modelo.excepciones;

import modelo.enums.EstadoTransaccion;

public class EstadoTransaccionInvalidoException extends BancoRuntimeException {

    public EstadoTransaccionInvalidoException(EstadoTransaccion origen, EstadoTransaccion destino) {
        super("Transición de estado inválida: no se puede pasar de " + origen + " a " + destino + ".");
    }
}
