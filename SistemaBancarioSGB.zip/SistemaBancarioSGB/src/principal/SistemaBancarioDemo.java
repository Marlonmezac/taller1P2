package principal;

import modelo.abstractas.Cuenta;
import modelo.abstractas.Empleado;
import modelo.banco.Banco;
import modelo.banco.Transaccion;
import modelo.cuentas.CuentaAhorros;
import modelo.cuentas.CuentaCorriente;
import modelo.cuentas.CuentaCredito;
import modelo.empleados.AsesorFinanciero;
import modelo.empleados.Cajero;
import modelo.empleados.GerenteSucursal;
import modelo.enums.EstadoTransaccion;
import modelo.enums.TipoDocumento;
import modelo.enums.Turno;
import modelo.excepciones.*;
import modelo.interfaces.Notificable;
import modelo.personas.ClienteEmpresarial;
import modelo.personas.ClienteNatural;

import java.time.LocalDate;

public class SistemaBancarioDemo {

    public static void main(String[] args) {

        System.out.println("╔══════════════════════════════════════════════════════╗");
        System.out.println("║      SISTEMA DE GESTIÓN BANCARIA — DEMO COMPLETO     ║");
        System.out.println("╚══════════════════════════════════════════════════════╝\n");

        // ─── Instancias globales ────────────────────────────────────────────────
        Banco banco = new Banco("Banco Nacional SGB");

        // Cuentas reutilizadas en varios escenarios
        CuentaAhorros cuentaAhorros        = new CuentaAhorros("AHO-001", 5000000, 0.05, 5);
        CuentaCorriente cuentaCorriente    = new CuentaCorriente("COR-001", 2000000, 500000, 15000);
        CuentaCredito cuentaCredito        = new CuentaCredito("CRE-001", 10000000, 0.02);
        CuentaAhorros cuentaAhorrosEmpresa = new CuentaAhorros("AHO-002", 20000000, 0.04, 10);

        // Clientes
        ClienteNatural cliente1 = new ClienteNatural(
                "CLI-001", "Carlos", "Rodríguez", LocalDate.of(1990, 5, 15),
                "carlos@email.com", TipoDocumento.CEDULA, "1023456789", true
        );
        ClienteNatural cliente2 = new ClienteNatural(
                "CLI-002", "María", "López", LocalDate.of(1985, 3, 22),
                "maria@email.com", TipoDocumento.CEDULA, "1098765432", false
        );
        ClienteEmpresarial clienteEmpresa = new ClienteEmpresarial(
                "CLI-003", "Juan", "Pérez", LocalDate.of(1975, 8, 10),
                "empresa@corp.com", "900.123.456-7", "TechCorp S.A.S",
                "Juan Pérez", true
        );

        // Empleados
        Cajero cajero = new Cajero(
                "EMP-001", "Sofía", "Martínez", LocalDate.of(1995, 4, 10),
                "sofia@banco.com", "CAJ-001", LocalDate.of(2022, 1, 10),
                2500000, Turno.MAÑANA, "Sucursal Centro"
        );
        AsesorFinanciero asesor = new AsesorFinanciero(
                "EMP-002", "Andrés", "García", LocalDate.of(1988, 11, 5),
                "andres@banco.com", "ASE-001", LocalDate.of(2018, 3, 15),
                4000000, 1500000, 50000000
        );
        GerenteSucursal gerente = new GerenteSucursal(
                "EMP-003", "Patricia", "Torres", LocalDate.of(1980, 7, 20),
                "patricia@banco.com", "GER-001", LocalDate.of(2010, 6, 1),
                8000000, "Sucursal Centro", 500000000
        );

        // ═══════════════════════════════════════════════════════════════════════
        // ESCENARIO 1 — Registrar clientes (herencia, super())
        // ═══════════════════════════════════════════════════════════════════════
        separador("ESCENARIO 1 — Registrar clientes (Herencia, super())");
        try {
            banco.registrarCliente(cliente1);
            banco.registrarCliente(cliente2);
            banco.registrarCliente(clienteEmpresa);
            System.out.println("  " + cliente1.obtenerResumen());
            System.out.println("  " + cliente2.obtenerResumen());
            System.out.println("  " + clienteEmpresa.obtenerResumen());
        } catch (CapacidadExcedidaException e) {
            System.out.println("[ERROR] " + e.getMessage());
        }

        // ═══════════════════════════════════════════════════════════════════════
        // ESCENARIO 2 — Abrir cuentas (polimorfismo, arrays estáticos)
        // ═══════════════════════════════════════════════════════════════════════
        separador("ESCENARIO 2 — Abrir una cuenta de cada tipo");
        try {
            banco.abrirCuenta("CLI-001", cuentaAhorros);
            banco.abrirCuenta("CLI-001", cuentaCorriente);
            banco.abrirCuenta("CLI-002", cuentaCredito);
            banco.abrirCuenta("CLI-003", cuentaAhorrosEmpresa);
        } catch (ClienteNoEncontradoException | CapacidadExcedidaException e) {
            System.out.println("[ERROR] " + e.getMessage());
        }

        // ═══════════════════════════════════════════════════════════════════════
        // ESCENARIO 3 — Depósito exitoso y CuentaBloqueadaException
        // ═══════════════════════════════════════════════════════════════════════
        separador("ESCENARIO 3 — Depósito exitoso y cuenta bloqueada");
        try {
            System.out.println("  Depositando $500.000 en cuenta ahorros...");
            cuentaAhorros.depositar(500000);
            System.out.println("  Depósito exitoso. Saldo actual: $" + String.format("%.2f", cuentaAhorros.consultarSaldo()));
        } catch (CuentaBloqueadaException e) {
            System.out.println("[ERROR] " + e.getMessage());
        }

        // Bloqueamos la cuenta y volvemos a intentar
        System.out.println("\n  Bloqueando cuenta corriente...");
        cuentaCorriente.setBloqueada(true);
        try {
            System.out.println("  Intentando depositar en cuenta bloqueada...");
            cuentaCorriente.depositar(200000);
        } catch (CuentaBloqueadaException e) {
            System.out.println("  [EXCEPCIÓN CAPTURADA] " + e.getMessage());
            System.out.println("  Código de error: " + e.getCodigoError());
        }
        cuentaCorriente.setBloqueada(false); // Desbloquear para siguientes escenarios

        // ═══════════════════════════════════════════════════════════════════════
        // ESCENARIO 4 — Retiro exitoso y SaldoInsuficienteException
        // ═══════════════════════════════════════════════════════════════════════
        separador("ESCENARIO 4 — Retiro exitoso y saldo insuficiente");
        try {
            System.out.println("  Retirando $1.000.000 de cuenta ahorros (saldo: $" + String.format("%.2f", cuentaAhorros.consultarSaldo()) + ")...");
            cuentaAhorros.retirar(1000000);
            System.out.println("  Retiro exitoso. Saldo actual: $" + String.format("%.2f", cuentaAhorros.consultarSaldo()));
        } catch (SaldoInsuficienteException | CuentaBloqueadaException e) {
            System.out.println("[ERROR] " + e.getMessage());
        }

        try {
            System.out.println("\n  Intentando retirar $99.000.000 (monto imposible)...");
            cuentaAhorros.retirar(99000000);
        } catch (SaldoInsuficienteException e) {
            System.out.println("  [EXCEPCIÓN CAPTURADA] " + e.getMessage());
            System.out.println("  Saldo actual: $" + String.format("%.2f", e.getSaldoActual()));
            System.out.println("  Monto solicitado: $" + String.format("%.2f", e.getMontoSolicitado()));
        } catch (CuentaBloqueadaException e) {
            System.out.println("[ERROR] " + e.getMessage());
        }

        // ═══════════════════════════════════════════════════════════════════════
        // ESCENARIO 5 — Transferencia entre dos cuentas (Transaccionable)
        // ═══════════════════════════════════════════════════════════════════════
        separador("ESCENARIO 5 — Transferencia entre cuentas (Transaccionable)");
        Transaccion transferencia = new Transaccion(
                "TRX-001", cuentaAhorros, cuentaAhorrosEmpresa, 500000, "Transferencia entre clientes"
        );
        try {
            System.out.println("  Ejecutando transferencia de $500.000...");
            transferencia.cambiarEstado(EstadoTransaccion.PROCESANDO);
            cuentaAhorros.retirar(500000);
            cuentaAhorrosEmpresa.depositar(500000);
            transferencia.cambiarEstado(EstadoTransaccion.COMPLETADA);
            cuentaAhorros.agregarAlHistorial(transferencia);
            cuentaAhorrosEmpresa.agregarAlHistorial(transferencia);
            System.out.println("  Transferencia completada.");
            System.out.println("  Saldo cuenta origen: $" + String.format("%.2f", cuentaAhorros.consultarSaldo()));
            System.out.println("  Saldo cuenta destino: $" + String.format("%.2f", cuentaAhorrosEmpresa.consultarSaldo()));
            System.out.print(transferencia.generarComprobante());
        } catch (SaldoInsuficienteException | CuentaBloqueadaException | CapacidadExcedidaException e) {
            System.out.println("[ERROR] " + e.getMessage());
        }

        // ═══════════════════════════════════════════════════════════════════════
        // ESCENARIO 6 — Polimorfismo calcularSalario() en array Empleado[]
        // ═══════════════════════════════════════════════════════════════════════
        separador("ESCENARIO 6 — Polimorfismo: calcularSalario() en array Empleado[]");
        try {
            cajero.setTransaccionesDia(45);
            asesor.setVentasMesActual(60000000);
            banco.registrarEmpleado(cajero);
            banco.registrarEmpleado(asesor);
            banco.registrarEmpleado(gerente);
        } catch (CapacidadExcedidaException e) {
            System.out.println("[ERROR] " + e.getMessage());
        }

        Empleado[] plantilla = banco.getEmpleados();
        for (int i = 0; i < plantilla.length; i++) {
            System.out.printf("  %-20s | Salario: $%,.2f%n",
                    plantilla[i].obtenerTipo(), plantilla[i].calcularSalario());
        }

        // ═══════════════════════════════════════════════════════════════════════
        // ESCENARIO 7 — Polimorfismo calcularInteres() en array Cuenta[]
        // ═══════════════════════════════════════════════════════════════════════
        separador("ESCENARIO 7 — Polimorfismo: calcularInteres() en array Cuenta[]");
        Cuenta[] cuentasRegistradas = banco.getCuentas();
        for (int i = 0; i < cuentasRegistradas.length; i++) {
            double interes = cuentasRegistradas[i].calcularInteres();
            String etiqueta = interes >= 0 ? "Interés/cargo mensual" : "Comisión mensual";
            System.out.printf("  %-10s #%-10s | %s: $%,.2f%n",
                    cuentasRegistradas[i].getTipoCuenta(),
                    cuentasRegistradas[i].getNumeroCuenta(),
                    etiqueta,
                    Math.abs(interes));
        }

        // ═══════════════════════════════════════════════════════════════════════
        // ESCENARIO 8 — Transición inválida → EstadoTransaccionInvalidoException
        // ═══════════════════════════════════════════════════════════════════════
        separador("ESCENARIO 8 — Transición de estado inválida");
        Transaccion txInvalida = new Transaccion(
                "TRX-002", cuentaAhorros, null, 100000, "Retiro en efectivo"
        );
        System.out.println("  Estado actual: " + txInvalida.getEstado());
        try {
            System.out.println("  Intentando pasar directamente a COMPLETADA (desde PENDIENTE)...");
            txInvalida.cambiarEstado(EstadoTransaccion.COMPLETADA); // Inválido
        } catch (EstadoTransaccionInvalidoException e) {
            System.out.println("  [EXCEPCIÓN UNCHECKED CAPTURADA] " + e.getMessage());
        }
        // Transición válida para demostrar
        txInvalida.cambiarEstado(EstadoTransaccion.PROCESANDO);
        txInvalida.cambiarEstado(EstadoTransaccion.RECHAZADA);
        System.out.println("  Estado final (tras transiciones válidas): " + txInvalida.getEstado());
        try {
            System.out.println("  Intentando salir de RECHAZADA (estado final)...");
            txInvalida.cambiarEstado(EstadoTransaccion.REVERTIDA); // Inválido
        } catch (EstadoTransaccionInvalidoException e) {
            System.out.println("  [EXCEPCIÓN UNCHECKED CAPTURADA] " + e.getMessage());
        }

        // ═══════════════════════════════════════════════════════════════════════
        // ESCENARIO 9 — Cajero intenta aprobar crédito → PermisoInsuficienteException
        // ═══════════════════════════════════════════════════════════════════════
        separador("ESCENARIO 9 — Permiso insuficiente: Cajero intenta aprobar crédito");
        try {
            System.out.println("  Cajero " + cajero.getNombreCompleto() + " intenta aprobar un crédito...");
            gerente.aprobarCredito(cajero, 50000000); // El solicitante NO es gerente
        } catch (PermisoInsuficienteException e) {
            System.out.println("  [EXCEPCIÓN UNCHECKED CAPTURADA] " + e.getMessage());
        }
        System.out.println("\n  Gerente aprueba el crédito correctamente:");
        gerente.aprobarCredito(gerente, 50000000); // El solicitante SÍ es gerente

        // ═══════════════════════════════════════════════════════════════════════
        // ESCENARIO 10 — notificar() (Notificable): acepta y no acepta
        // ═══════════════════════════════════════════════════════════════════════
        separador("ESCENARIO 10 — Interfaz Notificable");
        Notificable[] notificables = { cliente1, cliente2, clienteEmpresa };
        String[] mensajes = {
                "Su transferencia de $500.000 fue procesada exitosamente.",
                "Recordatorio: su cuota de crédito vence en 3 días.",
                "Su cuenta empresarial ha recibido un abono de $500.000."
        };
        for (int i = 0; i < notificables.length; i++) {
            notificables[i].notificar(mensajes[i]);
        }

        // ═══════════════════════════════════════════════════════════════════════
        // ESCENARIO 11 — registrarModificacion() y Auditable
        // ═══════════════════════════════════════════════════════════════════════
        separador("ESCENARIO 11 — Interfaz Auditable");
        System.out.println("  Registrando modificación en cuenta ahorros...");
        cuentaAhorros.registrarModificacion("asesor-andres-garcia");
        System.out.println("  Última modificación: " + cuentaAhorros.obtenerUltimaModificacion());
        System.out.println("  Usuario que modificó: " + cuentaAhorros.obtenerUsuarioModificacion());

        System.out.println("\n  Registrando modificación en cliente natural...");
        cliente1.registrarModificacion("cajero-sofia-martinez");
        System.out.println("  Última modificación: " + cliente1.obtenerUltimaModificacion());
        System.out.println("  Usuario que modificó: " + cliente1.obtenerUsuarioModificacion());

        // ═══════════════════════════════════════════════════════════════════════
        // ESCENARIO 12 — Nómina total del banco (polimorfismo, composición)
        // ═══════════════════════════════════════════════════════════════════════
        separador("ESCENARIO 12 — Nómina total del banco (Polimorfismo + Composición)");
        double nominaTotal = banco.calcularNominaTotal();
        System.out.println("  Desglose de nómina:");
        Empleado[] todosLosEmpleados = banco.getEmpleados();
        for (int i = 0; i < todosLosEmpleados.length; i++) {
            System.out.printf("    %-20s %-25s → $%,.2f%n",
                    todosLosEmpleados[i].obtenerTipo(),
                    todosLosEmpleados[i].getNombreCompleto(),
                    todosLosEmpleados[i].calcularSalario());
        }
        System.out.printf("%n  *** NÓMINA TOTAL DEL BANCO: $%,.2f ***%n", nominaTotal);

        System.out.println("\n╔══════════════════════════════════════════════════════╗");
        System.out.println("║           FIN DE LA DEMOSTRACIÓN — SGB               ║");
        System.out.println("╚══════════════════════════════════════════════════════╝");
    }

    private static void separador(String titulo) {
        System.out.println("\n┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ " + titulo);
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
    }
}
